

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class StudentLogin extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String un=request.getParameter("un");
		String pwd=request.getParameter("pwd");
		
		Model m= new Model();
		m.setUn(un);
		m.setPwd(pwd);
		//System.out.println(un);
		//System.out.println(pwd);

		int x= m.login();
		//System.out.println(x);

		if(x==1)
		{
			String name=m.getName();
			//String un=m.getUn();
			String age=m.getAge();
			String tenth=m.getTenth();
			String puc=m.getPuc();
			String engg=m.getEngg();
			String skills=m.getSkills();
			
			HttpSession session=request.getSession(true);
			session.setAttribute("name", name);
			session.setAttribute("age", age);
			session.setAttribute("un", un);
			session.setAttribute("tenth", tenth);
			session.setAttribute("puc", puc);
			session.setAttribute("engg", engg);
			session.setAttribute("skills", skills);
			
			response.sendRedirect("/Job/successLog.jsp");
		}
		else
		{
			response.sendRedirect("/Job/fail.html");
		}
		
	}

}
