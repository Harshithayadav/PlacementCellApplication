

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ChangeStenth
 */
public class ChangeStenth extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String changetenth=request.getParameter("changetenth");
		HttpSession session=request.getSession();
		String un=(String) session.getAttribute("un");
		Model m=new Model();
		m.setChangetenth(changetenth);
		m.setUn(un);
		//System.out.println(changetenth);
		//System.out.println(un);

		
		int x=m.changeTenth();
		//System.out.println(x);
		if(x==1)
		{
			response.sendRedirect("/Job/successSEdit.html");
		}
		else
		{
			response.sendRedirect("/Job/failSEdit.html");
		}
		}

}
