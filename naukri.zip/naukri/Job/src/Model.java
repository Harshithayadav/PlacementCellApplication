import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.OracleDriver;

public class Model {
	private String name;
	private String un;
	private String pwd;
	private String age;
	private String tenth;
	private String puc;
	private String engg;
	private String skills;
	private String FPemail;
	private String Fpwd;
	private String npwd;
	private String email;
	private String changeEmail;
	private String changetenth;
	private String changepuc;
	private String changeEngg;

	
	 Connection con;
	 PreparedStatement pstmt;
	 ResultSet res;
	 
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getUn() {
		return un;
	}
	public void setUn(String un) {
		this.un = un;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getTenth() {
		return tenth;
	}
	public void setTenth(String tenth) {
		this.tenth = tenth;
	}
	public String getPuc() {
		return puc;
	}
	public void setPuc(String puc) {
		this.puc = puc;
	}
	public String getEngg() {
		return engg;
	}
	public void setEngg(String engg) {
		this.engg = engg;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getFPemail() {
		return FPemail;
	}
	public void setFPemail(String fPemail) {
		FPemail = fPemail;
	}
	public String getFpwd() {
		return Fpwd;
	}
	public void setFpwd(String fpwd) {
		Fpwd = fpwd;
	}
	public String getNpwd() {
		return npwd;
	}
	public void setNpwd(String npwd) {
		this.npwd = npwd;
	}
	public String getChangeEmail() {
		return changeEmail;
	}
	public void setChangeEmail(String changeEmail) {
		this.changeEmail = changeEmail;
	}
	public String getChangetenth() {
		return changetenth;
	}
	public void setChangetenth(String changetenth) {
		this.changetenth = changetenth;
	}
	public String getChangepuc() {
		return changepuc;
	}
	public void setChangepuc(String changepuc) {
		this.changepuc = changepuc;
	}
	public String getChangeEngg() {
		return changeEngg;
	}
	public void setChangeEngg(String changeEngg) {
		this.changeEngg = changeEngg;
	}


	Model()
	{
		try {
			DriverManager.registerDriver(new OracleDriver());
			con=DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE","system","system");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	 int register()
		{
			
				String s="insert into applicant values(?,?,?,?,?,?,?,?,?)";
				try {
					pstmt=con.prepareStatement(s);
					pstmt.setString(1, name);
					pstmt.setString(2, un);
					pstmt.setString(3, pwd);
					pstmt.setString(4, age);
					pstmt.setString(5, tenth);
					pstmt.setString(6, puc);
					pstmt.setString(7,engg);
					pstmt.setString(8, skills);
					pstmt.setString(9, email);

					
					int x=pstmt.executeUpdate();
					return x;
					
				} catch (SQLException e) {
					e.printStackTrace();
					
				}
				
				return 0;

			
		}
	public int login() {
		String s="select * from applicant where user_name=? and password=?";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, un);
			pstmt.setString(2, pwd);
			
			res=pstmt.executeQuery();
			if(res.next()==true)
			{
				name=res.getString("name");
				un=res.getString("user_name");
				pwd=res.getString("password");
				age=res.getString("age");
				tenth=res.getString("tenth_marks");
				puc=res.getString("puc_marks");
				engg=res.getString("engg_marks");
				skills=res.getString("skills");
				//email=res.getString("email");

				return 1;
			}
			else
			{
				return 0;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	
	public int resetPwd() {
		String s="update applicant set password=? where email=?";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, Fpwd);
			pstmt.setString(2, FPemail);
			
			int x=pstmt.executeUpdate();
			return x;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	public int changePwd() {
		String s="update applicant set password=? where user_name=?";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, npwd);
			pstmt.setString(2, un);
			
			int x=pstmt.executeUpdate();
			return x;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	public int changeMail() {
		String s="update applicant set email=? where user_name=?";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, changeEmail);
			pstmt.setString(2, un);
			
			int x=pstmt.executeUpdate();
			return x;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	public int changeTenth() {
		String s="update applicant set tenth_marks=? where user_name=?";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, changetenth);
			pstmt.setString(2, un);
			
			int x=pstmt.executeUpdate();
			return x;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	public int changePuc() {
		String s="update applicant set puc_marks=? where user_name=?";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, changepuc);
			pstmt.setString(2, un);
			
			int x=pstmt.executeUpdate();
			return x;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	public int changeEngg() {
		String s="update applicant set engg_marks=? where user_name=?";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, changeEngg);
			pstmt.setString(2, un);
			
			int x=pstmt.executeUpdate();
			return x;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	

}
