

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class ChangeSpuc
 */
public class ChangeSpuc extends HttpServlet {
protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String changepuc=request.getParameter("changepuc");
		HttpSession session=request.getSession();
		String un=(String) session.getAttribute("un");
		Model m=new Model();
		m.setChangepuc(changepuc);
		m.setUn(un);
		//System.out.println(changepuc);
		//System.out.println(un);

		
		int x=m.changePuc();
		//System.out.println(x);
		if(x==1)
		{
			response.sendRedirect("/Job/successSEdit.html");
		}
		else
		{
			response.sendRedirect("/Job/failSEdit.html");
		}
		}

}
