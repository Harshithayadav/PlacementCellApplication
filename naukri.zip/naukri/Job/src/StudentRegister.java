

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class StudentRegister extends HttpServlet {
	
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String name = request.getParameter("name");
		String un = request.getParameter("un");
		String pwd = request.getParameter("pwd");
		String age = request.getParameter("age");
		String tenth = request.getParameter("tenth");
		String puc = request.getParameter("puc");
		String engg= request.getParameter("engg");
		String skills=request.getParameter("skills");
		
		Model m= new Model();
		m.setName(name);
		m.setUn(un);
		m.setPwd(pwd);
		m.setAge(age);
		m.setTenth(tenth);
		m.setPuc(puc);
		m.setEngg(engg);
		m.setSkills(skills);
		
		int x=m.register();
		
		if(x==1)
		{
			response.sendRedirect("/Job/sRegStudent.html");
		}
		else
		{
			response.sendRedirect("/Job/fail.html");
		}
	}

}
