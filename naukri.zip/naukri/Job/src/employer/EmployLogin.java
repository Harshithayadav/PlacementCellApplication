package employer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class EmployLogin extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String Empun=request.getParameter("Empun");
		String Emppwd=request.getParameter("Emppwd");
		String Email=request.getParameter("Email");

		Model1 m1= new Model1();
		m1.setEmpun(Empun);
		m1.setEmppwd(Emppwd);
		
		int x= m1.login();
		if(x==1)
		{
			String Empname=m1.getEmpname();
			
			
			HttpSession session=request.getSession(true);
			session.setAttribute("Empname", Empname);
			session.setAttribute("Email", Email);
			session.setAttribute("Empun", Empun);
			session.setAttribute("Emppwd", Emppwd);
			
			
			response.sendRedirect("/Job/successLoge.jsp");
		}
		else
		{
			response.sendRedirect("/Job/fail.html");
		}
		
	}

	
	}

