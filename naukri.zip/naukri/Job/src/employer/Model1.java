package employer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import oracle.jdbc.OracleDriver;

public class Model1 {
	private String Empname;
	private String Email;
	private String Empun;
	private String Emppwd;
	private String cname;
	private String salary;
	private String location;
	private String tenth;
	private String puc;
	private String engg;
	private String skills;
	private String jobrole;
	private String FPemail;
	private String Fpwd;
	private String npwd;

	 Connection con;
	 PreparedStatement pstmt;
	 ResultSet res;
	 
	public String getEmpname() {
		return Empname;
	}
	public void setEmpname(String empname) {
		Empname = empname;
	}
	public String getEmail() {
		return Email;
	}
	public void setEmail(String email) {
		Email = email;
	}
	public String getEmpun() {
		return Empun;
	}
	public void setEmpun(String empun) {
		Empun = empun;
	}
	public String getEmppwd() {
		return Emppwd;
	}
	public void setEmppwd(String emppwd) {
		Emppwd = emppwd;
	}
	
	Model1()
	{
		try {
			DriverManager.registerDriver(new OracleDriver());
			con=DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/XE","system","system");

		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
	
	 int register()
		{
				String s="insert into employee values(?,?,?)";
				try {
					pstmt=con.prepareStatement(s);
					pstmt.setString(1, Empname);
					pstmt.setString(2, Empun);
					pstmt.setString(3, Emppwd);
					
					int x=pstmt.executeUpdate();
					return x;
					
				} catch (SQLException e) {
					e.printStackTrace();	
				}
				return 0;
		}
	 
	 public int login() {
			String s="select * from employee where user_name=? and password=?";
			try {
				pstmt=con.prepareStatement(s);
				pstmt.setString(1, Empun);
				pstmt.setString(2, Emppwd);
				
				res=pstmt.executeQuery();
				if(res.next()==true)
				{
					Empname=res.getString("Empname");
					Email=res.getString("Email");
					
					return 1;
				}
				else
				{
					return 0;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
			return 0;
		}
	public String getCname() {
		return cname;
	}
	public void setCname(String cname) {
		this.cname = cname;
	}
	public String getJobrole() {
		return jobrole;
	}
	public void setJobrole(String jobrole) {
		this.jobrole = jobrole;
	}

	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public String getTenth() {
		return tenth;
	}
	public void setTenth(String tenth) {
		this.tenth = tenth;
	}
	public String getPuc() {
		return puc;
	}
	public void setPuc(String puc) {
		this.puc = puc;
	}
	public String getEngg() {
		return engg;
	}
	public void setEngg(String engg) {
		this.engg = engg;
	}
	public String getSkills() {
		return skills;
	}
	public void setSkills(String skills) {
		this.skills = skills;
	}
	public String getFPemail() {
		return FPemail;
	}
	public void setFPemail(String FPemail) {
		this.FPemail = FPemail;
	}
	public String getFpwd() {
		return Fpwd;
	}
	public void setFpwd(String Fpwd) {
		this.Fpwd = Fpwd;
	}
	public String getNpwd() {
		return npwd;
	}
	public void setNpwd(String npwd) {
		this.npwd = npwd;
	}
	public int postJob() {
		
		String s="insert into jobs values(?,?,?,?,?,?,?,?,?)";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, cname);
			pstmt.setString(2, Email);
			pstmt.setString(3, jobrole);
			pstmt.setString(4, tenth);
			pstmt.setString(5, puc);
			pstmt.setString(6, engg);
			pstmt.setString(7, salary);
			pstmt.setString(8, skills);
			pstmt.setString(9, location);

			int x=pstmt.executeUpdate();
			return x;

		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	public int resetPwd() {
		String s="update employee set password=? where email=?";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, Fpwd);
			pstmt.setString(2, FPemail);
			
			int x=pstmt.executeUpdate();
			return x;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		return 0;
	}
	
	public int changePwd() {
		String s="update employee set password=? where user_name=?";
		try {
			pstmt=con.prepareStatement(s);
			pstmt.setString(1, npwd);
			pstmt.setString(2, Empun);
			
			int x=pstmt.executeUpdate();
			return x;
			
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return 0;
	}
	
	


}
