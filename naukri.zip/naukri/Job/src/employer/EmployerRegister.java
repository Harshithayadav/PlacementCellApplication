package employer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class EmployerRegister extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String Empname = request.getParameter("Empname");
		String Email = request.getParameter("Email");
		String Empun = request.getParameter("Empun");
		String Emppwd = request.getParameter("Emppwd");
		
		
		Model1 m= new Model1();
		m.setEmpname(Empname);
		m.setEmail(Email);
		m.setEmpun(Empun);
		m.setEmppwd(Emppwd);
		
		
		int x=m.register();
		if(x==1)
		{
			response.sendRedirect("/Job/sRegEmployer.html");
		}
		else
		{
			response.sendRedirect("/Job/fail.html");
		}
	}
}
