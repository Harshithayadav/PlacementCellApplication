package employer;

public class Otp {
	public static int otp;
	public int otp()
	{
		double d= Math.random();
		d=d*1000000;
		int OTP=(int) d;
		return OTP;
		
	}

}
