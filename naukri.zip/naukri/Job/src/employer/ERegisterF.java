package employer;

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class ERegisterF
 */
public class ERegisterF implements Filter {

    /**
     * Default constructor. 
     */
    public ERegisterF() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		String Empname=request.getParameter("Empname");
		String Email=request.getParameter("Email");
		String Empun=request.getParameter("Empun");
		String Emppwd=request.getParameter("Emppwd");
		String Empcpwd=request.getParameter("Empcpwd");
		
		if(Empname.length()!=0&& Email.length()!=0 && Empun.length()!=0&& Emppwd.length()!=0&& Empcpwd.length()!=0)
		{
			if(Emppwd.equals(Empcpwd))
			{
				chain.doFilter(request, response);
			}
			else
			{
				((HttpServletResponse)response).sendRedirect("emismatchReg.html");

			}
		}
		else
		{
			((HttpServletResponse)response).sendRedirect("eErrorReg.html");
		}
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
