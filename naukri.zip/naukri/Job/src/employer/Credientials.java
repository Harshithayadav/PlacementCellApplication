package employer;

public class Credientials {

		public static String email="amruakshu101@gmail.com";
		public static String pwd="Amruta8861";

	

}
