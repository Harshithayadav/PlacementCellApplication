package employer;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class JobDetails extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String cname = request.getParameter("cname");
		String jobrole = request.getParameter("jobrole");
		String Email=request.getParameter("Email");
		String tenth = request.getParameter("tenth");
		String puc = request.getParameter("puc");
		String engg= request.getParameter("engg");
		String salary= request.getParameter("salary");
		String skills=request.getParameter("skills");
		String location= request.getParameter("location");
		
		Model1 m=new Model1();
		m.setCname(cname);
		m.setJobrole(jobrole);
		m.setEmail(Email);
		m.setTenth(tenth);
		m.setPuc(puc);
		m.setEngg(engg);
		m.setSalary(salary);
		m.setLocation(location);
		m.setSkills(skills);
		
		int x=m.postJob();
		if(x==1)
		{
			HttpSession session=request.getSession(true);
			session.setAttribute("cname", cname);
			session.setAttribute("Email", Email);
			session.setAttribute("tenth", tenth);
			session.setAttribute("puc", puc);
			session.setAttribute("engg", engg);
			session.setAttribute("salary", salary);
			session.setAttribute("skills", skills);
			session.setAttribute("location", location);


			response.sendRedirect("/Job/successJobUpdate.jsp");
		}
		else
		{
			response.sendRedirect("/Job/failJobupdate.html");
		}

	}

}
