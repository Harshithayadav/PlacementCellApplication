

import java.io.IOException;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet Filter implementation class SRegisterF
 */
public class SRegisterF implements Filter {

    /**
     * Default constructor. 
     */
    public SRegisterF() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		String name=request.getParameter("name");
		String un=request.getParameter("un");
		String pwd=request.getParameter("pwd");
		String cpwd=request.getParameter("cpwd");
		String age=request.getParameter("age");
		String tenth=request.getParameter("tenth");
		String puc=request.getParameter("puc");
		String engg=request.getParameter("engg");
		String skills=request.getParameter("skills");
		String email=request.getParameter("email");





		
		if(name.length()!=0&& un.length()!=0&& pwd.length()>6&& cpwd.length()>6 && age.length()!=0 && tenth.length()!=0 && puc.length()!=0 && engg.length()!=0 && skills.length()!=0 && email.length()!=0)
		{
			if(pwd.equals(cpwd))
			{
				chain.doFilter(request, response);
			}
			else
			{
				((HttpServletResponse)response).sendRedirect("errorStudentReg.html");

			}
		}
		else
		{
			((HttpServletResponse)response).sendRedirect("sErrorReg.html");
		}
		
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
