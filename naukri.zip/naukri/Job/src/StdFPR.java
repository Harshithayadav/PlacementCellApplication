

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class StdFPR extends HttpServlet {
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String uotp=request.getParameter("uotp");
		HttpSession session1=request.getSession(true);
		String otp1=(String) session1.getAttribute("otp1");
		//System.out.println("uotp ="+uotp);
		//System.out.println("otp1 ="+otp1);

		if(uotp.equals(otp1))
		{
			response.sendRedirect("/Job/stdFPRP.html");
		}
		else
		{
			response.sendRedirect("/Job/stdFP.html");

		}

	
	}
}
