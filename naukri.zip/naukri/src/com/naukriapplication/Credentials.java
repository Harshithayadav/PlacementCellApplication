package com.naukriapplication;

public class Credentials
{
static String email="yadavharshitha578@gmail.com";
static String pwd="YADAVharshitha@8";

}
